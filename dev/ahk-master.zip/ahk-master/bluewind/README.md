# bluewind

Call bluewind with [Win+Space] on Windows 7.

## Overview

[Win+Space] --- (AutoHotKey) --- [Win+A] --- bluewind

## bluewind settings

bluewind / Users / (user) / bluewind.ini

```
Call_key=65
Call_Mod=8
Call_S=Win+A
```

