AutoHotKey Scripts
==================

### NewFile (Ctrl+Alt+N)

Create a new blank file. This script is a Fork of [this](https://gist.github.com/davejamesmiller/1965432).

### NewTextFile (Ctrl+Shift+T)

Create a new blank text file.
The difference of "NewFile" is auto appending ".txt" extension.

### bluewind (Win+Space)

Call bluewind with [Win+Space] on Windows 7.
[(more...)](https://github.com/syon/ahk/tree/master/bluewind)
