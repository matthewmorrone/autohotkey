const fs = require('fs')
const utils = require('./utils.js')
const regex = /[^\w\s]/

let glyphs = fs.getFileAsLines("index.tsv").map(line => line.split("\t"))

let map = []
glyphs.each(function(args) {
    map[args[0]] = args[1]
})

let dict = fs.getFileAsLines("cmu.tsv")
    // .map(line => line.replaceAll(/(\w+)\d/, "$1"))
    .map(line => line.replaceAll(/(\w+)0/, "$1"))
    .map(line => line.replaceAll(/(\w+)1/, "$1"))
    .map(line => line.replaceAll(/(\w+)2/, "$1"))
    .filter(line => !line.match(/\'/g))
    // .filter(line => !line.match(/\(\d\)/g))
    .map(line => line.split("\t"))
    .map(line => [line[0].replace(/\(\d\)/g, ""), line[1].replace(/(\w+)/g, function(m, i) {
        return map[m];
    }).split(" ").join("")])

let result = ""
dict.each(function(line) {
    result += line + "\n"
})

fs.setFile("out.tsv", result)

