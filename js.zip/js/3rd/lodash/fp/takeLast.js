module.exports = require('./takeRight');
