var convert = require('./convert'),
    func = convert('groupBy', require('../groupBy'));

func.placeholder = require('./placeholder');
module.exports = func;
