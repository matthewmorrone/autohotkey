var convert = require('./convert'),
    func = convert('negate', require('../negate'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
